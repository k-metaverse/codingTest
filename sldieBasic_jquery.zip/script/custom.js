$(function(){
    let num = 0; //1,2,3
    let pos=0; //0,-600,-1200,-1800
    $('.slide > div').animate({'left':pos+'%'},300);
    // animation:mv 10s linear infinite;
    // @keyframes mv {
    //     0%{left:0;}
    //     30%{left:0;}
    //     35%{left:-100%;}
    //     65%{left:-100%;}
    //     70%{left:-200%;}
    //     97%{left:-200%;}
    //     100%{left:0;}  
    // }  
    setInterval(function(){
        
        if(num < 2) {
            num++;
        }
        else {
            num = 0;
        }   
        pos=-100*num;
        $('.slide > div').animate({'left':pos+'%'},300)
    }, 3500)
})